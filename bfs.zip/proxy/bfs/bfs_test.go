package bfs

import (
	"testing"
	"time"
	//	"fmt"
)

func TestBfs(t *testing.T) {
	var (
		err error
	)

}

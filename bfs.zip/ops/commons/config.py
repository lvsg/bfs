# -*- encoding:utf8 -*-

# store.
store_admin_port = 6063
store_stat_port = 6061
store_block_size = 32 # GB

# zookeeper  port:2181.
zk_hosts = '127.0.0.1'

# log dir.
log_dir = '/tmp'

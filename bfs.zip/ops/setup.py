from setuptools import setup

setup(
    name="bfs",
    version="1.0",
    install_requires=[
        "requests",
        "flask",
    ],
)
